//  Criar uma página onde o 
// usuário insere seu ano de 
// nascimento e o JavaScript 
// calcula e exibe sua idade

let year;

year = 2025;

function userIdade (){
    const dt_birthday = prompt(`Insira seu ano de nascimento: `)
    const idade = year - dt_birthday 
     document.getElementById("div").innerHTML = `Sua idade é: ${idade} anos`;
};