 function calcular(operacao) {
      const n1 = parseFloat(document.getElementById('n1').value);
      const n2 = parseFloat(document.getElementById('n2').value);
      let resultado = 0;

      if (isNaN(n1) || isNaN(n2)) {
        document.getElementById('resultado').innerText = "Por favor, preencha os dois números.";
        return;
      }

      switch (operacao) {
        case 'soma':
          resultado = n1 + n2;
          break;
        case 'subtrair':
          resultado = n1 - n2;
          break;
        case 'multiplicar':
          resultado = n1 * n2;
          break;
        case 'dividir':
          if (n2 === 0) {
            document.getElementById('resultado').innerText = "Não é possível dividir por zero.";
            return;
          }
          resultado = n1 / n2;
          break;
      }

      document.getElementById('resultado').innerText = "O Resultado é " + resultado;
    }