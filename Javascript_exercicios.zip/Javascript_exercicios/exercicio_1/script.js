function nomeUsuario() {
    let nome = prompt(`Qual é o seu nome?`);
    document.getElementById("message").innerText= `Olá,  ${nome}`;
}
window.onload = nomeUsuario;



