 function mudarCor(cor) {
            document.body.style.backgroundColor = cor;
        }