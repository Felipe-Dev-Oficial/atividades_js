function parIMpar () {
  let number = prompt(`Digite um número:`);
  if (number % 2 === 0) {
    document.getElementById("div").innerHTML = `O número ${number} é par`;
  } else {
    document.getElementById("div").innerHTML = `O número ${number} é ímpar`;
  }
}

parIMpar();